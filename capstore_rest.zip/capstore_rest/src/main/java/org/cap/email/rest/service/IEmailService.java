package org.cap.email.rest.service;

import java.util.List;

import org.cap.email.rest.model.Email;

public interface IEmailService {

	public List<Email> getAll();

	public void save(Email email);

}
