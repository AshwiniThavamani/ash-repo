package org.cap.email.rest.service;

import java.util.List;

import org.cap.email.rest.dao.EmailDao;
import org.cap.email.rest.model.Email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("emailService")
public class EmailServiceImpl implements IEmailService{

	@Autowired
	private EmailDao emailDao;
	
	@Override
	public List<Email> getAll() {
		
		return emailDao.findAll();
	}

	@Override
	public void save(Email email) {
		
		emailDao.save(email);
	}

}
