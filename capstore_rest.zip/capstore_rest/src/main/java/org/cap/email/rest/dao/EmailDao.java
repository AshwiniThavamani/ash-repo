package org.cap.email.rest.dao;

import org.cap.email.rest.model.Email;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("emailDao")
public interface EmailDao extends JpaRepository<Email,Integer> {



}
