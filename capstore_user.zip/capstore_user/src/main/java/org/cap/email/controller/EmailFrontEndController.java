package org.cap.email.controller;


import javax.validation.Valid;
import org.cap.email.model.Email;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class EmailFrontEndController {

	@RequestMapping("/inbox")
	public String getAllEmail(ModelMap map) {
		
		
		final String uri="http://localhost:8083/capRest/api/v1/emails";
		RestTemplate restTemplate=new RestTemplate();
		
		Email[] email= restTemplate.getForObject(uri, Email[].class);
		
		
		map.put("email",email);
		map.put("emails", new Email());
		
		return "inbox";
	}
	
	@PostMapping("/saveEmail")
	public String saveEmail(@Valid @ModelAttribute("email") Email email,BindingResult result) 
	{
		if(!result.hasErrors()) {
			
			final String uri="http://localhost:8083/capRest/api/v1/emails";
			RestTemplate restTemplate=new RestTemplate();
			restTemplate.postForEntity(uri,email,Email.class);
		
		}
		
		return "compose";
	}
	
}
